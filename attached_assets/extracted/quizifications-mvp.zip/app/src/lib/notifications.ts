// src/lib/notifications.ts

import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import { Platform } from 'react-native';
import { supabase } from './supabase';
import { QuizQuestion } from '../types';

// Configure notification behavior
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});

export async function registerForPushNotifications(userId: string): Promise<string | null> {
  if (!Device.isDevice) {
    console.log('Must use physical device for push notifications');
    return null;
  }

  // Check existing permissions
  const { status: existingStatus } = await Notifications.getPermissionsAsync();
  let finalStatus = existingStatus;

  // Request if not granted
  if (existingStatus !== 'granted') {
    const { status } = await Notifications.requestPermissionsAsync();
    finalStatus = status;
  }

  if (finalStatus !== 'granted') {
    console.log('Failed to get push token for push notification!');
    return null;
  }

  // Get the token
  const token = (await Notifications.getExpoPushTokenAsync()).data;

  // Save to database
  await supabase
    .from('users')
    .update({ push_token: token })
    .eq('id', userId);

  // Android specific channel
  if (Platform.OS === 'android') {
    Notifications.setNotificationChannelAsync('quiz', {
      name: 'Quiz Notifications',
      importance: Notifications.AndroidImportance.HIGH,
      vibrationPattern: [0, 250, 250, 250],
      lightColor: '#c8ff00',
    });
  }

  return token;
}

export async function scheduleQuizNotification(
  question: QuizQuestion,
  delayMinutes: number
): Promise<string> {
  const identifier = await Notifications.scheduleNotificationAsync({
    content: {
      title: '🧠 Quizifications',
      subtitle: question.sourceName,
      body: question.question,
      data: {
        questionId: question.id,
        question: question.question,
        answers: question.answers,
        correctIndex: question.correctIndex,
        source: question.source,
        sourceName: question.sourceName,
      },
      categoryIdentifier: 'quiz',
    },
    trigger: {
      seconds: delayMinutes * 60,
    },
  });

  return identifier;
}

export async function scheduleNextQuiz(
  getQuestion: () => Promise<QuizQuestion | null>,
  intervalMinutes: number
): Promise<void> {
  // Cancel any existing scheduled notifications
  await Notifications.cancelAllScheduledNotificationsAsync();

  // Get a question
  const question = await getQuestion();
  if (!question) {
    console.log('No questions available to schedule');
    return;
  }

  // Schedule it
  await scheduleQuizNotification(question, intervalMinutes);
}

export async function cancelAllNotifications(): Promise<void> {
  await Notifications.cancelAllScheduledNotificationsAsync();
}

export async function getScheduledNotifications(): Promise<Notifications.NotificationRequest[]> {
  return await Notifications.getAllScheduledNotificationsAsync();
}

// Listener setup for handling notification interactions
export function setupNotificationListeners(
  onNotificationReceived: (notification: Notifications.Notification) => void,
  onNotificationResponse: (response: Notifications.NotificationResponse) => void
) {
  const receivedSubscription = Notifications.addNotificationReceivedListener(onNotificationReceived);
  const responseSubscription = Notifications.addNotificationResponseReceivedListener(onNotificationResponse);

  return () => {
    receivedSubscription.remove();
    responseSubscription.remove();
  };
}
